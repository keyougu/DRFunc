globalVariables(c('GO_gene','GO_pathway','GO_pathway_gene','KEGG_gene','KEGG_pathway','KEGG_pathway_gene','MsigDB_gene','MsigDB_pathway','MsigDB_pathway_gene'))
SigPairEnrich=function(SigP,geneid,database=c('GO_pathway','KEGG_pathway','MsigDB_pathwayC2'),FDR=0.05,fdrmethod=c('BH','bonferroni','p_value')){
#---------------------------------------------------------
###--Sort gene in pathway



    if(!is.numeric(FDR)){
        stop("the input FDR must be numeric!\n");
    }

    if(database=='GO_pathway'){
        data(list=c("GO_gene","GO_pathway","GO_pathway_gene"),envir = environment())#environment
        uni_gene=GO_gene;
        pathway_info=as.matrix(paste(GO_pathway[,1],GO_pathway[,2],sep="_"));
        path_info_mtx=GO_pathway_gene;
    }else if(database=='KEGG_pathway'){
        data(list=c("KEGG_gene","KEGG_pathway","KEGG_pathway_gene"),envir = environment())
        uni_gene=KEGG_gene;
        pathway_info=as.matrix(paste(KEGG_pathway[,1],KEGG_pathway[,2],sep="_"));
        path_info_mtx=KEGG_pathway_gene;
    }else if(database=='MsigDB_pathwayC2'){
        data(list=c("MsigDB_gene","MsigDB_pathway","MsigDB_pathway_gene"),envir = environment())
        uni_gene=MsigDB_gene;
        pathway_info=MsigDB_pathway;
        path_info_mtx=MsigDB_pathway_gene;
    }else{
        stop("please input the parameter:'database'");
    }
s=as.matrix(order(uni_gene));
UniG=as.matrix(uni_gene[s,]);
Path=as.matrix(path_info_mtx[,s]);
##----------------------------------
# Profile Gene in pathway
IntG=as.matrix(sort(intersect(geneid,UniG)));#The genes involved in the pathway which contained in geneid
#---------------------------------------
# pathway gene in Profile
a=UniG %in% IntG;
Path=Path[,a];#IntG genes in profile
L=length(IntG);#background genes
m=SigP[,1] %in% IntG;
n=SigP[,2] %in% IntG;
k=(m+n)==2;
L_sigP=sum(k);#Gene pairs involved in pathway,(num of interest pairs)
if(L_sigP==0){
    stop("There is no interest pairs involved in pathway");
}
BP=choose(L,2);#background pairs
##-----------------------------------------------------------
#--SigP enrich

LP=length(Path[,1]);#path num
HyperP=matrix(,nrow=LP,ncol=6);#"pathway_index","p_value","adjusted p-value","k","n","x","m".
HyperP[,3]=L_sigP;
HyperP[,4]=BP;


for (i in 1:LP){
    Temp1=Path[i,];
    TempG=IntG[which(Temp1==1),];
    HyperP[i,1]=i;
    if (length(TempG)<2){

        HyperP[i,2]=1;
        HyperP[i,5]=0;
        HyperP[i,6]=0;
        next;
    }else{
        BPinPath=choose(length(TempG),2);
        HyperP[i,6]=BPinPath;
        a=SigP[,1] %in% TempG;
        b=SigP[,2] %in% TempG;
        c=(a+b)==2;
        if (sum(c)==0){
            HyperP[i,2]=1;
            HyperP[i,5]=0;

            next;
        }else{
            L_sigPPath=sum(c);
            HyperP[i,5]=L_sigPPath;
        }
    }
    p1=matrix(1-phyper(L_sigPPath-1,BPinPath,BP-BPinPath,L_sigP));
    HyperP[i,2]=p1;
}


if(fdrmethod=='BH'){
q1=as.matrix(p.adjust(HyperP[,2],method="fdr",length(HyperP[,2])),ncol=1);
SigPath=cbind(HyperP[,1:2],q1,HyperP[,3:6]);
q1fdr=(q1<=FDR);
SigPath_info=pathway_info[q1fdr,];
SigPath=SigPath[q1fdr,];
}else if(fdrmethod=='bonferroni'){
    Pval=FDR/LP;
    SigPath=cbind(HyperP[,1:2],HyperP[,2],HyperP[,3:6]);
    q1fdr=(HyperP[,2]<=Pval);
    SigPath_info=pathway_info[q1fdr,];
    SigPath=SigPath[q1fdr,];
}else if(fdrmethod=='p_value'){
    Pval=FDR;
    SigPath=cbind(HyperP[,1:2],HyperP[,2],HyperP[,3:6]);
    q1fdr=(HyperP[,2]<=Pval);
    SigPath_info=pathway_info[q1fdr,];
    SigPath=SigPath[q1fdr,];
}
if(length(SigPath[,1])==0){
    print("Can't find the pathway for statistically significant enrichment under the threshold value FDR!\n");
}else{
res=cbind(SigPath_info,SigPath);
COL_NAME=matrix(c("pathway","pathway_index","p_value","adjusted p-value","k","n","x","m"),nrow=1)
colnames(res)=COL_NAME;
res;
}
}

