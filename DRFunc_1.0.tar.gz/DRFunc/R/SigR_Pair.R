SigR_Pair=function(expControl,expCase,geneid,FDR=0.05,fdrmethod=c('BH','bonferroni','p_value')){
######################Genes with significant differences in rank order###############
# input: expControl is expCase
# SPairBC114=SigR_Pair(expCtrol,expCase,RefGene,0.05,'BH');
# in program: expControl as reference
#


  expControl=as.matrix(expControl);
  expCase=as.matrix(expCase);
  geneid=as.matrix(geneid);


L=length(geneid);#The number of all genes
LN=length(expControl[1,]);#The number of expControl samples
LT=length(expCase[1,]);#The number of expCase samples
if(L<2){
    stop("The number of genes is not enough to form a pair!\n");
}
if(nrow(expControl)!=nrow(expCase)|nrow(expControl)!=L){
    stop("Genes in these two expression profiles should correspond to the Gene in the geneid matrix!\n");
}
if(!is.numeric(FDR)){
    stop("the input FDR must be numeric!\n");
}

RE=matrix(,ncol=8);

for (i in 1:(L-1)){
    Temp1=expControl[i,];
    Temp2=expCase[i,];
    TempN=matrix(rep(Temp1,L-i),byrow=T,nrow=L-i);
    TempT=matrix(rep(Temp2,L-i),byrow=T,nrow=L-i);
    TempN1=expControl[(i+1):L,];
    TempT1=expCase[(i+1):L,];
    a=as.matrix(rowSums((TempN-TempN1)>0));#control samples with Gi>Gj
    b=as.matrix(rowSums((TempT-TempT1)>0));#case samples with Gi>Gj
    c=LN-a;#control samples with Gi<Gj
    d=LT-b;#case samples with Gi<Gj
    Temp3=cbind(a,c,b,d);
    P1=as.matrix(1-phyper(a-1,a+b,c+d,LN));
    P2=as.matrix(1-phyper(c-1,c+d,a+b,LN));
    P=cbind(P1,P2);
    C=as.matrix(apply(P,1,min));
    I=as.matrix(apply(P,1,which.min)) ;



    if(fdrmethod=='BH'){
        q=as.matrix(p.adjust(C,method="fdr",length(C)));
        r=matrix(which(q<=FDR));
        q=as.matrix(q[r,]);
    }else if(fdrmethod=='bonferroni'){
        Pval=FDR/choose(L,2);
        r=matrix(which(C<=Pval));
        q=as.matrix(C[r,])
    }else if(fdrmethod=='p_value'){
        Pval=FDR;
        r=matrix(which(C<=Pval));
        q=as.matrix(C[r,])
    }

    if (length(r)==0){
        next;
    }else{
        Temp=cbind(as.matrix(rep(i,length(r))),as.matrix(r+i),as.matrix(I[r,]),q,matrix(Temp3[r,],ncol=ncol(Temp3)));

    }
 RE=rbind(RE,Temp);

}
if(length(RE[,1])==1){
    stop("Can't find the gene pairs for statistically significant difference under the threshold value FDR!\n");
}else{
    RE=matrix(RE[2:nrow(RE),],ncol = ncol(RE));

}

a=(RE[,3]==2);
Temp1=matrix(RE[a,],ncol = ncol(RE));
RE1=cbind(matrix(Temp1[,2],ncol=1),matrix(Temp1[,1],ncol=1),matrix(Temp1[,4],ncol=1),matrix(Temp1[,5:ncol(Temp1)],ncol=4));
a=(RE[,3]==1);
Temp1=matrix(RE[a,],ncol=ncol(RE));
RE2=cbind(matrix(Temp1[,1:2],ncol=2),matrix(Temp1[,4],ncol=1),matrix(Temp1[,5:ncol(Temp1)],ncol=4));
RES=rbind(RE1,RE2);

gene_i=matrix(geneid[RES[,1],],ncol=1);
gene_j=matrix(geneid[RES[,2],],ncol=1);
RES=matrix(as.character(cbind(gene_i,gene_j,RES)),byrow=F,ncol =9);
COL_NAME=matrix(c("gene_i","gene_j","gene_i_index_in_geneid","gene_j_index_in_geneid","adjusted p-value","control_samples_with_Gi>Gj","control_samples_with_Gi<Gj","case_samples_with_Gi>Gj","case_samples_with_Gi<Gj"),nrow=1)
colnames(RES)=COL_NAME;
RES;

}
